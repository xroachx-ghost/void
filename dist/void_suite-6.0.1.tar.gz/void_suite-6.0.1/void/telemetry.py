from __future__ import annotations

"""
VOID Telemetry System

Opt-in privacy-first analytics and crash reporting.

PROPRIETARY SOFTWARE
Copyright (c) 2024 Roach Labs. All rights reserved.
Made by James Michael Roach Jr.
Unauthorized copying, modification, distribution, or disclosure is prohibited.
"""
