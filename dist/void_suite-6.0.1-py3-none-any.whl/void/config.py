"""
VOID CONFIGURATION

PROPRIETARY SOFTWARE
Copyright (c) 2024 Roach Labs. All rights reserved.
Made by James Michael Roach Jr.
Unauthorized copying, modification, distribution, or disclosure is prohibited.
"""

from pathlib import Path
from typing import Any, Dict

import json


class Config:
    """Configuration constants."""

    VERSION = "6.0.1"
    CODENAME = "AUTOMATION"
    APP_NAME = "Void"

    # Theme
    THEME_NAME = "Veilstorm Protocol"
    THEME_TAGLINE = "Anonymous ops console with zero-friction automation."
    THEME_SLOGANS = [
        "Kali dragon in motion. Anonymous mask on command.",
        "Operate silent. Execute fast. Leave no trace.",
        "Encrypted workflows. Shadow-grade automation.",
    ]
    GUI_THEME = {
        "bg": "#070b12",
        "panel": "#111a28",
        "panel_alt": "#0c1420",
        "accent": "#00f5d4",
        "accent_soft": "#7bffda",
        "accent_alt": "#7c3aed",
        "text": "#e6f1ff",
        "muted": "#9cb1cf",
        "shadow": "#03050a",
        "button_bg": "#0f1826",
        "button_active": "#1b2a3d",
        "button_text": "#00f5d4",
        "border": "#1b2a3d",
        "gradient_start": "#0a1220",
        "gradient_end": "#16243b",
        "splash_start": "#04060b",
        "splash_end": "#1a2540",
        "dragon": "#00f5d4",
        "mask": "#e6f1ff",
    }

    # Timeouts
    TIMEOUT_SHORT = 5
    TIMEOUT_MEDIUM = 30
    TIMEOUT_LONG = 300

    # Paths
    BASE_DIR = Path.home() / ".void"
    CONFIG_PATH = BASE_DIR / "config.json"
    DB_PATH = BASE_DIR / "void.db"
    LOG_DIR = BASE_DIR / "logs"
    BACKUP_DIR = BASE_DIR / "backups"
    EXPORTS_DIR = BASE_DIR / "exports"
    CACHE_DIR = BASE_DIR / "cache"
    REPORTS_DIR = BASE_DIR / "reports"
    MONITOR_DIR = BASE_DIR / "monitoring"
    SCRIPTS_DIR = BASE_DIR / "scripts"
    TOOLS_DIR = BASE_DIR / "tools"
    ANDROID_PLATFORM_TOOLS_DIR = TOOLS_DIR / "platform-tools"

    # Security
    MAX_INPUT_LENGTH = 256

    # Features
    ENABLE_AUTO_BACKUP = True
    ENABLE_REPORTS = True
    ENABLE_MONITORING = True
    ENABLE_ANALYTICS = True
    SMART_ENABLED = True
    SMART_AUTO_DEVICE = True
    SMART_PREFER_LAST_DEVICE = True
    SMART_AUTO_DOCTOR = True
    SMART_SUGGESTIONS = True
    SMART_SAFE_GUARDS = True

    # Gemini assistant (GUI)
    GEMINI_MODEL = "gemini-1.5-flash"
    GEMINI_API_BASE = "https://generativelanguage.googleapis.com/v1beta/models"
    GEMINI_HISTORY_LIMIT = 24

    # Privacy controls
    COLLECT_IMEI = True
    COLLECT_SERIAL = True
    COLLECT_FINGERPRINT = True
    STORE_IMEI = True
    STORE_SERIAL = True
    STORE_FINGERPRINT = True

    # Crypto
    ALLOW_INSECURE_CRYPTO = False

    DEFAULT_SETTINGS: Dict[str, Any] = {
        "enable_auto_backup": ENABLE_AUTO_BACKUP,
        "enable_reports": ENABLE_REPORTS,
        "enable_analytics": ENABLE_ANALYTICS,
        "exports_dir": str(EXPORTS_DIR),
        "reports_dir": str(REPORTS_DIR),
        "smart_enabled": SMART_ENABLED,
        "smart_auto_device": SMART_AUTO_DEVICE,
        "smart_prefer_last_device": SMART_PREFER_LAST_DEVICE,
        "smart_auto_doctor": SMART_AUTO_DOCTOR,
        "smart_suggestions": SMART_SUGGESTIONS,
        "smart_safe_guards": SMART_SAFE_GUARDS,
        "collect_imei": COLLECT_IMEI,
        "collect_serial": COLLECT_SERIAL,
        "collect_fingerprint": COLLECT_FINGERPRINT,
        "store_imei": STORE_IMEI,
        "store_serial": STORE_SERIAL,
        "store_fingerprint": STORE_FINGERPRINT,
    }

    @classmethod
    def setup(cls) -> None:
        """Create necessary directories."""
        cls.BASE_DIR.mkdir(parents=True, exist_ok=True)
        cls.load_settings()
        cls.ensure_directories()

    @classmethod
    def ensure_directories(cls) -> None:
        """Ensure configured directories exist."""
        for path in [
            cls.BASE_DIR,
            cls.LOG_DIR,
            cls.BACKUP_DIR,
            cls.EXPORTS_DIR,
            cls.CACHE_DIR,
            cls.REPORTS_DIR,
            cls.MONITOR_DIR,
            cls.SCRIPTS_DIR,
            cls.TOOLS_DIR,
        ]:
            path.mkdir(parents=True, exist_ok=True)

    @classmethod
    def read_config(cls) -> Dict[str, Any]:
        """Read the JSON config file."""
        try:
            with cls.CONFIG_PATH.open("r", encoding="utf-8") as handle:
                data = json.load(handle)
                return data if isinstance(data, dict) else {}
        except FileNotFoundError:
            return {}
        except json.JSONDecodeError:
            return {}

    @classmethod
    def write_config(cls, data: Dict[str, Any]) -> None:
        """Persist JSON config data."""
        cls.BASE_DIR.mkdir(parents=True, exist_ok=True)
        with cls.CONFIG_PATH.open("w", encoding="utf-8") as handle:
            json.dump(data, handle, indent=2, sort_keys=True)

    @classmethod
    def _normalize_settings(cls, settings: Dict[str, Any]) -> Dict[str, Any]:
        merged = {**cls.DEFAULT_SETTINGS, **(settings or {})}

        def _parse_dir(value: Any, fallback: Path) -> Path:
            if not value:
                return fallback
            try:
                return Path(value).expanduser()
            except (TypeError, ValueError):
                return fallback

        exports_dir = _parse_dir(merged.get("exports_dir"), cls.EXPORTS_DIR)
        reports_dir = _parse_dir(merged.get("reports_dir"), cls.REPORTS_DIR)

        normalized = {
            "enable_auto_backup": bool(merged.get("enable_auto_backup")),
            "enable_reports": bool(merged.get("enable_reports")),
            "enable_analytics": bool(merged.get("enable_analytics")),
            "exports_dir": str(exports_dir),
            "reports_dir": str(reports_dir),
            "smart_enabled": bool(merged.get("smart_enabled", cls.SMART_ENABLED)),
            "smart_auto_device": bool(merged.get("smart_auto_device", cls.SMART_AUTO_DEVICE)),
            "smart_prefer_last_device": bool(
                merged.get("smart_prefer_last_device", cls.SMART_PREFER_LAST_DEVICE)
            ),
            "smart_auto_doctor": bool(merged.get("smart_auto_doctor", cls.SMART_AUTO_DOCTOR)),
            "smart_suggestions": bool(merged.get("smart_suggestions", cls.SMART_SUGGESTIONS)),
            "smart_safe_guards": bool(merged.get("smart_safe_guards", cls.SMART_SAFE_GUARDS)),
            "collect_imei": bool(merged.get("collect_imei", cls.COLLECT_IMEI)),
            "collect_serial": bool(merged.get("collect_serial", cls.COLLECT_SERIAL)),
            "collect_fingerprint": bool(merged.get("collect_fingerprint", cls.COLLECT_FINGERPRINT)),
            "store_imei": bool(merged.get("store_imei", cls.STORE_IMEI)),
            "store_serial": bool(merged.get("store_serial", cls.STORE_SERIAL)),
            "store_fingerprint": bool(merged.get("store_fingerprint", cls.STORE_FINGERPRINT)),
        }

        cls.ENABLE_AUTO_BACKUP = normalized["enable_auto_backup"]
        cls.ENABLE_REPORTS = normalized["enable_reports"]
        cls.ENABLE_ANALYTICS = normalized["enable_analytics"]
        cls.EXPORTS_DIR = exports_dir
        cls.REPORTS_DIR = reports_dir
        cls.SMART_ENABLED = normalized["smart_enabled"]
        cls.SMART_AUTO_DEVICE = normalized["smart_auto_device"]
        cls.SMART_PREFER_LAST_DEVICE = normalized["smart_prefer_last_device"]
        cls.SMART_AUTO_DOCTOR = normalized["smart_auto_doctor"]
        cls.SMART_SUGGESTIONS = normalized["smart_suggestions"]
        cls.SMART_SAFE_GUARDS = normalized["smart_safe_guards"]
        cls.COLLECT_IMEI = normalized["collect_imei"]
        cls.COLLECT_SERIAL = normalized["collect_serial"]
        cls.COLLECT_FINGERPRINT = normalized["collect_fingerprint"]
        cls.STORE_IMEI = normalized["store_imei"]
        cls.STORE_SERIAL = normalized["store_serial"]
        cls.STORE_FINGERPRINT = normalized["store_fingerprint"]

        return normalized

    @classmethod
    def load_settings(cls) -> Dict[str, Any]:
        """Load settings from the config file and apply them."""
        data = cls.read_config()
        settings = data.get("settings", {}) if isinstance(data, dict) else {}
        return cls._normalize_settings(settings)

    @classmethod
    def save_settings(cls, settings: Dict[str, Any]) -> Dict[str, Any]:
        """Save settings to the config file."""
        normalized = cls._normalize_settings(settings)
        data = cls.read_config()
        data["settings"] = normalized
        cls.write_config(data)
        cls.ensure_directories()
        return normalized
